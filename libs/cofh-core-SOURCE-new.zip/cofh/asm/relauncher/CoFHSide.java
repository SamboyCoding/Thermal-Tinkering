package cofh.asm.relauncher;

public enum CoFHSide {
	NONE, CLIENT, SERVER;
}
