/**
 * (C) 2014 Team CoFH / CoFH / Cult of the Full Hub
 * http://www.teamcofh.com
 */
@API(apiVersion = CoFHLibProps.VERSION, owner = "CoFHLib", provides = "CoFHLib|util|helpers")
package cofh.lib.util.helpers;

import cofh.lib.CoFHLibProps;
import cpw.mods.fml.common.API;

