package tconstruct.library.modifier;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import tconstruct.library.armor.*;

public class ActiveArmorMod
{
    /* Ticks for every armor piece on client and server */
    public void onArmorTick (World world, EntityPlayer player, ItemStack itemStack, ArmorCore armor, ArmorPart type)
    {

    }
}
