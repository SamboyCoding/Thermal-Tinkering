package tconstruct.library.component;

import java.util.List;

public interface IComponentHolder
{
    public List<LogicComponent> getComponents ();
}
