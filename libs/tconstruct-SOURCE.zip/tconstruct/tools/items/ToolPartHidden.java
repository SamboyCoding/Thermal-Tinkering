package tconstruct.tools.items;

import java.util.List;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;

@Deprecated
public class ToolPartHidden extends ToolPart
{

    public ToolPartHidden(String textureType, String name)
    {
        super(textureType, name);
    }

    @Override
    public void getSubItems (Item id, CreativeTabs tab, List list)
    {

    }
}
