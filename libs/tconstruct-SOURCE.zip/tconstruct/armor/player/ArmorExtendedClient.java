package tconstruct.armor.player;

public class ArmorExtendedClient extends ArmorExtended
{
    /*
     * public void recalculateSkills(EntityPlayer player, TPlayerStats stats) {
     * TConstruct.logger.info("Client skills"); if (inventory[1] != null &&
     * inventory[1].getItem() == TContent.glove) { if
     * (TProxyClient.skillList.size() < 1) { try {
     * TProxyClient.skillList.add(SkillRegistry
     * .skills.get("Wall Building").copy()); } catch (Exception e) {
     * e.printStackTrace(); } } } else { if (TProxyClient.skillList.size() > 0)
     * { TProxyClient.skillList.remove(0); } } }
     */
}
