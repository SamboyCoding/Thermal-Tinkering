package tconstruct.weaponry.client;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public enum CrosshairType {
    SQUARE,
    TIP,
    WEIRD,
    SPIKE
}
