package cofh.thermalexpansion.api.fuels;

public interface IMagmaticHandler {

	public boolean addFuel(String name, int energy);

	public boolean removeFuel(String name);

}
